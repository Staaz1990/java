function epaule() 
{
 	var ep = document.getElementById('tepaule');
      
      if(ep.style.display == 'none') 
    {
        ep.style.display = 'block';
    } 
      else 
    {
        ep.style.display = 'none';
     }
}

function coude() 
{
 	var cd = document.getElementById('tcoude');
      
      if(cd.style.display == 'none') 
    {
        cd.style.display = 'block';
    } 
      else 
    {
        cd.style.display = 'none';
     }
}


